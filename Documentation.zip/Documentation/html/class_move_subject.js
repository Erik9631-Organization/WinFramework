var class_move_subject =
[
    [ "AddOnMoveSubscriber", "class_move_subject.html#a044a8a15a422bd15b21c43924297e983", null ],
    [ "NotifyOnMoveSubscribers", "class_move_subject.html#a3bcee1fefee92db28ce7f13cc931b9d9", null ],
    [ "RemoveOnMoveSubscriber", "class_move_subject.html#ac2a00d5737d229c03a569c2d93133d82", null ]
];