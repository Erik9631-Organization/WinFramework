var class_generic_obj =
[
    [ "GenericObj", "class_generic_obj.html#a8789d6d58d69a8de684891033f6b9011", null ],
    [ "Get", "class_generic_obj.html#a052c563f0511d37bde7099ae1b7df226", null ]
];