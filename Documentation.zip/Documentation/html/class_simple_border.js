var class_simple_border =
[
    [ "SimpleBorder", "class_simple_border.html#a84a312532f19ec6b5385dc405ef79aca", null ],
    [ "~SimpleBorder", "class_simple_border.html#af13eca127d69291d6b3279e5f36e886d", null ],
    [ "AddRenderable", "class_simple_border.html#aa766b1d1c322466c2b12c66dfcbb17f2", null ],
    [ "GetColor", "class_simple_border.html#a2cde228213a18a7baadd0db77b09b516", null ],
    [ "GetPercentualPosition", "class_simple_border.html#abbbefdc906b7b62d3c31e5b415ca2eb2", null ],
    [ "GetReflectionContainer", "class_simple_border.html#a5143b32fa78061ff28a247e045433896", null ],
    [ "GetRenderables", "class_simple_border.html#ace767a0b24924dd394bb65f74a8c53e5", null ],
    [ "GetSize", "class_simple_border.html#a840a9a32f81225a19adeb62259c60baa", null ],
    [ "HasMethod", "class_simple_border.html#a809d6a3cccbc444fa68c3ff2bd07f6cc", null ],
    [ "HorizontalCentering", "class_simple_border.html#a1f88e0388151ed406c8beacfd9f09d24", null ],
    [ "OnRender", "class_simple_border.html#a8452516558fe1451ea3a518a8f4a253a", null ],
    [ "RemoveRenderable", "class_simple_border.html#ac60f850268eb152f557cc958ef554787", null ],
    [ "Repaint", "class_simple_border.html#a7339e49d62e79707fcd9e8e3ba1df9e1", null ],
    [ "SetBorderStyle", "class_simple_border.html#abf598a172cb204630defee115fcebf22", null ],
    [ "SetColor", "class_simple_border.html#ab8421767379d5cd2a037ce68523c8ca7", null ],
    [ "SetScalingType", "class_simple_border.html#a8504eb0c0215909486cd108ebdf246a9", null ],
    [ "SetThickness", "class_simple_border.html#a50d7a8cdd5a4f13888b88d8fabbf099d", null ],
    [ "SetVerticalCentering", "class_simple_border.html#a5f072dd56083766ac0120255be1a15c5", null ],
    [ "reflectionContainer", "class_simple_border.html#a770d34b15c653a96503d0b60fa8b4dc0", null ]
];