var class_resize_subject =
[
    [ "AddOnResizeSubscriber", "class_resize_subject.html#a08d3f6857763c0d5c703601df71f447f", null ],
    [ "NotifyOnResizeSubscribers", "class_resize_subject.html#a06299d18effa9cebd3d50fc960b9a03b", null ],
    [ "RemoveOnResizeSubscriber", "class_resize_subject.html#a6b27cad0e436ca32b5582c3e614cc58a", null ]
];