var class_text =
[
    [ "Text", "class_text.html#a027b36cc994dd7959fa40adacd734982", null ],
    [ "AddRenderable", "class_text.html#a53705895335451aa1fd622c9c350689c", null ],
    [ "GetAlignment", "class_text.html#a6d7766b0acad117a846c562b2b467ff5", null ],
    [ "GetLineAlignment", "class_text.html#a5ad7b08f95cb6d766241e95954dc805b", null ],
    [ "GetPosition", "class_text.html#a17df84029c27a08fb04c64bfdc5e0624", null ],
    [ "GetReflectionContainer", "class_text.html#a2c8fa9d3786753f10f4bceea43f7cec0", null ],
    [ "GetRenderables", "class_text.html#aba457e5b72efb75ce5ac6eb4b8439fa0", null ],
    [ "GetText", "class_text.html#a98ac9b212506362a3e2a6b9337d17de9", null ],
    [ "HasMethod", "class_text.html#a7ece0f2401b96ad09b1514737416d058", null ],
    [ "OnRender", "class_text.html#aa2ef280be31859afe89b2eff2d534165", null ],
    [ "RemoveRenderable", "class_text.html#a87f911d0c96b62ec4c23dba39f61e91c", null ],
    [ "Repaint", "class_text.html#a8a49776ad81abc46192eac44522d52ed", null ],
    [ "SetAlignment", "class_text.html#a90fd1611819a955c93e7b6a5747fcd13", null ],
    [ "SetColor", "class_text.html#a443aa2171d4150a8df97bb9c914fce07", null ],
    [ "SetFontSize", "class_text.html#a58d6496f1eac33d42f55086617898efb", null ],
    [ "SetLineAlignment", "class_text.html#a88614910c7562b04c90c0d68740fe274", null ],
    [ "SetPercentualPosition", "class_text.html#ac1eeba8e20c85eb3f1c4b64aa6661948", null ],
    [ "SetPosition", "class_text.html#a7830dbf9c931351d4bd40f2bbf35d511", null ],
    [ "SetText", "class_text.html#ad30609f12ec59c6aa3e79d7fcd36a080", null ]
];