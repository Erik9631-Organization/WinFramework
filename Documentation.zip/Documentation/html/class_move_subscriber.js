var class_move_subscriber =
[
    [ "OnMove", "class_move_subscriber.html#a8ccfcba4f86581ae332364314a4fa08b", null ]
];