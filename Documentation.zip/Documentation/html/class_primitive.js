var class_primitive =
[
    [ "Primitive", "class_primitive.html#a14a4bc9e4d52df6ef27449069a009970", null ]
];