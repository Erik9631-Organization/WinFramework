var class_event_update_info =
[
    [ "EventUpdateInfo", "class_event_update_info.html#ad82e681d7617cad3a3545798e1918d8f", null ],
    [ "DisableFlag", "class_event_update_info.html#a537456214e6dd492c23ab91e9ef47ae5", null ],
    [ "HasFlag", "class_event_update_info.html#ae86f15d556600c0e31487ed6fa12d110", null ],
    [ "SetFlags", "class_event_update_info.html#abefc349962d4c2ec5fc6e9a29a0ed23b", null ]
];