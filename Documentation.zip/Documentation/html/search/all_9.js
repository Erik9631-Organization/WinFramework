var searchData=
[
  ['j_244',['J',['../class_input_manager.html#a876aab4c35a86dc4636c01b6afd761f6aff44570aca8241914870afbc310cdb85',1,'InputManager']]],
  ['junja_245',['Junja',['../class_input_manager.html#a876aab4c35a86dc4636c01b6afd761f6aed6114f847ec2d8fbbd40a98f965f8ef',1,'InputManager']]]
];
