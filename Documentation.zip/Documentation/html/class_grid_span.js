var class_grid_span =
[
    [ "GridSpan", "class_grid_span.html#a3b191c6eb964767a9fff0d5d598be8b5", null ],
    [ "CreateColumnSpan", "class_grid_span.html#a97f200e4c2c4ce3e097a6c1024451730", null ],
    [ "CreateRowSpan", "class_grid_span.html#a22d025920be31d865db85e081d0ed05c", null ],
    [ "CreateSpan", "class_grid_span.html#ac83982a76f51468677718509100d9586", null ],
    [ "GetGridColumnEnd", "class_grid_span.html#a9aec37459c2c121d949f397b7a19681a", null ],
    [ "GetGridColumnStart", "class_grid_span.html#aa1e00d6dd80db862dccf9c5aab6653a5", null ],
    [ "GetGridRowEnd", "class_grid_span.html#aaa5b4bb67b3d0f59ed98a81fc9c67c13", null ],
    [ "GetGridRowStart", "class_grid_span.html#a770afa5f655b40bef214825bdf03a730", null ],
    [ "isSet", "class_grid_span.html#a0624ab07b9b332826a01e0936c8a2979", null ]
];