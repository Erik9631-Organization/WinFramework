var class_default_property_parser =
[
    [ "GetProperty", "class_default_property_parser.html#a87041568d87d7b58d7b7f74c2c56d7bb", null ],
    [ "HasProperty", "class_default_property_parser.html#a0854641c0bf17c5b3199c17edfa2c765", null ],
    [ "Set_GetColorFunction", "class_default_property_parser.html#a0e97d107850e6f7382bec07029bf61a9", null ],
    [ "Set_GetThicknessFunction", "class_default_property_parser.html#a62e3b08b849241f30e92bd04c2208b42", null ],
    [ "Set_SetBorderStyleFunction", "class_default_property_parser.html#aa902933d34d800ed5bf97a421797cbd5", null ],
    [ "Set_SetColorFunction", "class_default_property_parser.html#a83afd0db1ec24e6f425725191b84fcf4", null ],
    [ "Set_SetFontSizeFunction", "class_default_property_parser.html#ac238b90318cb36fa10f188608e6d3286", null ],
    [ "Set_SetThicknessFunction", "class_default_property_parser.html#a912a4cac4e57f6bd330e380cda34e325", null ],
    [ "SetProperty", "class_default_property_parser.html#af076ca816315692640aeb4aa670cdad0", null ]
];