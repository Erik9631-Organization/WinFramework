var class_label =
[
    [ "Label", "class_label.html#a180990410b79b70beee7707f4360a901", null ],
    [ "Label", "class_label.html#af8f2bccf9faadcb2ca964bd2347dde24", null ],
    [ "Label", "class_label.html#ab1897b9da5baa2f89ea09cba5dddd126", null ],
    [ "GetBackground", "class_label.html#a5614b15dee859328a8ee7a715f97dbac", null ],
    [ "GetText", "class_label.html#ae3bf96785ba046b4a29c2638f44e9d3e", null ],
    [ "SetBackground", "class_label.html#a4da77e4853d3a5067d0efd75dcfe3da0", null ],
    [ "SetText", "class_label.html#a9fd9edb2adc8c974287f1e0d5bfa5f3e", null ]
];