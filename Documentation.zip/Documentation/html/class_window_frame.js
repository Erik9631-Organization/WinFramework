var class_window_frame =
[
    [ "WindowFrame", "class_window_frame.html#ad67ea33fc1542e5ae743f6e5c5728425", null ],
    [ "WindowFrame", "class_window_frame.html#acce7f05e5edb0bf7149a84f5ee0ea3f9", null ],
    [ "WindowFrame", "class_window_frame.html#a40b54a34d646ac6903db50628cd4a312", null ],
    [ "~WindowFrame", "class_window_frame.html#a5f2a7de1ed77d33ab0e394fc8e67726d", null ],
    [ "Add", "class_window_frame.html#a929685e4b7d92bc12982d9a8f063e689", null ],
    [ "AddWindowExtendedStyle", "class_window_frame.html#a3b5cec226d78e6336bec999a33ab7dea", null ],
    [ "AddWindowStyle", "class_window_frame.html#abb4f05b61f0b3534d64644a578476cc8", null ],
    [ "CloseWindow", "class_window_frame.html#ae1f221ab720fe0d2543a44290309b174", null ],
    [ "NotifyOnKeyDown", "class_window_frame.html#a486350b49ae876fdb9590b9c5b232f89", null ],
    [ "NotifyOnKeyPressed", "class_window_frame.html#ae2bb490b5ffa56910f7b5adf88f6b284", null ],
    [ "NotifyOnKeyUp", "class_window_frame.html#ab4d3032f13a6350538de88f49a99aeb0", null ],
    [ "NotifyOnMouseDown", "class_window_frame.html#ae43e561da745e2b5620ae8dfb604342c", null ],
    [ "RemoveWindowExtendedStyle", "class_window_frame.html#ac119ecf04546f380ae3b4bbc86f70ba8", null ],
    [ "RemoveWindowStyle", "class_window_frame.html#a5ea859d578ddd8c7c83cffedd87975af", null ],
    [ "Repaint", "class_window_frame.html#a25347c33646be87dc103406fabf163ee", null ],
    [ "SetPosition", "class_window_frame.html#a5aefd805bfb8b786c261adc2c578626c", null ],
    [ "SetPosition", "class_window_frame.html#abec27f8610ff28c77a6ea68969d9ddeb", null ],
    [ "SetSize", "class_window_frame.html#ad8b4d003ee5341e56ebf9daebd68f647", null ],
    [ "SetSize", "class_window_frame.html#a263333641c4f757d20ee4918c0fdb890", null ],
    [ "UpdateWindow", "class_window_frame.html#abbdc91c934c2f42e63ad2b5c8e2bc91d", null ],
    [ "initDone", "class_window_frame.html#adfb77ef2627bff0fdb5aacd5f0b8a7ff", null ]
];