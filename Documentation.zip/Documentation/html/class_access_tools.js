var class_access_tools =
[
    [ "Invoke", "class_access_tools.html#a9699e0c96acd2b68592384c431d14c38", null ],
    [ "RegisterClassMethod", "class_access_tools.html#a787598a08f5d31d5e15f046f642aa226", null ]
];