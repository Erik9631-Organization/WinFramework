var class_core_window_frame =
[
    [ "CoreWindowFrame", "class_core_window_frame.html#a0179c1e87d809d833b79d7ca88d56882", null ],
    [ "~CoreWindowFrame", "class_core_window_frame.html#af43eac0733d4f21fa9daed12267b0204", null ],
    [ "AddRenderable", "class_core_window_frame.html#ab19338234e1d01256def433469efdfbc", null ],
    [ "CloseWindow", "class_core_window_frame.html#a7ff9b506b27a30c2ecaa18a144c5d321", null ],
    [ "ConsoleWrite", "class_core_window_frame.html#a84691b60e7e8bbdca970cb6ff74e354b", null ],
    [ "GetHdc", "class_core_window_frame.html#abd468febba0e3d8758d6e04e4792f9eb", null ],
    [ "GetRenderables", "class_core_window_frame.html#a41997e93ae05601d73610fc2e1d49992", null ],
    [ "GetWindowHandle", "class_core_window_frame.html#a9d06a4b88e9baecb3e2e6ee513d051d6", null ],
    [ "GetWrapperFrame", "class_core_window_frame.html#a3e4d0e55885e0b9d769322c7a894b959", null ],
    [ "MessageLoop", "class_core_window_frame.html#a4b521203109e607fcd96aeba2cf625ce", null ],
    [ "OnRender", "class_core_window_frame.html#a4f9a97dcb41d8b01342e27e361a4ec16", null ],
    [ "ProcessMessage", "class_core_window_frame.html#a11aa3be121c9eb86e5d9abe52f79e081", null ],
    [ "RedrawWindow", "class_core_window_frame.html#ae214fcdc1bc47d30082b6391f9bd9f11", null ],
    [ "RemoveRenderable", "class_core_window_frame.html#a3812e960b70a74a0d4493c8ee913cd67", null ],
    [ "RemoveWindowAttributes", "class_core_window_frame.html#ae4a27dd38b9f4c70a7a289b3f40bcef7", null ],
    [ "Repaint", "class_core_window_frame.html#ad44cbd27b5e8c5c47e12d9dfa7492525", null ],
    [ "SetWindowAttributes", "class_core_window_frame.html#a0dc0e1afc6a2b78dd39eb4199bf17f4f", null ],
    [ "UnicodeConsoleWrite", "class_core_window_frame.html#ab9b21f9efa05d424be8401d6cd65ecca", null ],
    [ "UpdateScale", "class_core_window_frame.html#af09a41fd883d815a57c7c4f166376936", null ]
];