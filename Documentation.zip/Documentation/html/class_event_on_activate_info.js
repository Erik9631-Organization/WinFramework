var class_event_on_activate_info =
[
    [ "EventOnActivateInfo", "class_event_on_activate_info.html#a1f9a2eea938564172e2a613b51bcbc42", null ],
    [ "IsActive", "class_event_on_activate_info.html#ae2ac17a5549d842a9d5b5ecb22a63879", null ]
];