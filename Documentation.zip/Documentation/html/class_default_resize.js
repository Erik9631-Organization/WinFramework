var class_default_resize =
[
    [ "DefaultResize", "class_default_resize.html#a40589e688a37a785941c545cfd49d0dc", null ],
    [ "AddOnResizeSubscriber", "class_default_resize.html#af5ca00078572cc3e5444cae74d52e73e", null ],
    [ "GetHeight", "class_default_resize.html#ae860b66033a49e31c891f1e14c29301c", null ],
    [ "GetSize", "class_default_resize.html#ab9ccc0e894152c16b31eaff025588c0c", null ],
    [ "GetWidth", "class_default_resize.html#ac16ee1e2648e8cd0fa729a4f573c4cc5", null ],
    [ "NotifyOnResizeSubscribers", "class_default_resize.html#a9f2b4923a828a6b5db3608daf06e50c1", null ],
    [ "RemoveOnResizeSubscriber", "class_default_resize.html#a5e23dcfbe4f67e62d17e955d5f15ef5a", null ],
    [ "SetHeight", "class_default_resize.html#aee3a1832f4728d4da8e97d30bc4f4504", null ],
    [ "SetSize", "class_default_resize.html#a73d5f44d3e4090eba94acb1384ec236f", null ],
    [ "SetSize", "class_default_resize.html#a6ce7dd0966f67240b9a218bf421fe289", null ],
    [ "SetWidth", "class_default_resize.html#ab1671e2f1969fe4eaeeab8fba7c4c9b3", null ]
];