var class_update_subscriber =
[
    [ "OnUpdate", "class_update_subscriber.html#a011a28a98c9079a14505cf37be37eb80", null ]
];