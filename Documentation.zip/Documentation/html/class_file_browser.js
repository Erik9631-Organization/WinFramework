var class_file_browser =
[
    [ "FileBrowser", "class_file_browser.html#a98b79145b653fec5ce021f55753a9149", null ],
    [ "FileBrowser", "class_file_browser.html#a497b8f105abe221111a071b3b6fac03e", null ],
    [ "AddFilter", "class_file_browser.html#a4e8427d000ffe0a3437e85e950589d4b", null ],
    [ "AllowMultiSelect", "class_file_browser.html#aa6966e18979c9dd5476c408dbe9e6f7f", null ],
    [ "CreatePrompt", "class_file_browser.html#a975b1a6ad9dfe740f616ee36be207216", null ],
    [ "EnableResizing", "class_file_browser.html#a55490b45d27c45b050d620abef81f45b", null ],
    [ "FileMustExist", "class_file_browser.html#a8d20be7373a8af7a2bf1c591b7f666a2", null ],
    [ "GetFileName", "class_file_browser.html#abc05e7d57f7db7690960d65c40b42ad4", null ],
    [ "GetFileStream", "class_file_browser.html#a44c0de387a78acb975ac2f829c9555bf", null ],
    [ "GetPath", "class_file_browser.html#a26f2432d744cf6bc47e34033a0f4eba0", null ],
    [ "Open", "class_file_browser.html#af527369465c396ed324f9b0ec2757f2d", null ],
    [ "Save", "class_file_browser.html#a348bc30476d89a29c63a350974c99daf", null ],
    [ "SetDefaultDirectory", "class_file_browser.html#a3a1998cb18712c0a279b1e168b621375", null ],
    [ "SetDefaultExtention", "class_file_browser.html#a36a145af6c2fc3209b15bdcbf0d34b0c", null ],
    [ "SetFlags", "class_file_browser.html#a43ef5a14757b4f578ec40552308563dd", null ],
    [ "SetSelectedFilter", "class_file_browser.html#a1cd62c24999d4fb8f8371c070631c504", null ],
    [ "SetTitle", "class_file_browser.html#a44a0824d854eb9384a9f5220b2283eb5", null ],
    [ "ShowHiddenFiles", "class_file_browser.html#ab5653e7a8d70e7bbee97e47b28b79d0c", null ]
];