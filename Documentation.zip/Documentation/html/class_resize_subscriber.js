var class_resize_subscriber =
[
    [ "OnResize", "class_resize_subscriber.html#a0318f1dc8f486dbd576b44c226d0e3ca", null ]
];