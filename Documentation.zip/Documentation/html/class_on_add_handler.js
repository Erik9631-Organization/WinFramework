var class_on_add_handler =
[
    [ "AddOnAddSubscriber", "class_on_add_handler.html#ad4833aa98fac00ecf8cad014f06fd3e6", null ],
    [ "NotifyOnAddInfo", "class_on_add_handler.html#a03af932ca3462b8d72757edc6c435446", null ],
    [ "RemoveOnAddSubscriber", "class_on_add_handler.html#afdf54a6b89690b65d1bda59701637436", null ]
];