var class_resizable =
[
    [ "GetHeight", "class_resizable.html#ace7e6fc0a32c0d779c2efbac5a579d89", null ],
    [ "GetSize", "class_resizable.html#a866c23f49fbae4a8ba40bb6332a54557", null ],
    [ "GetWidth", "class_resizable.html#ad8829be59ee9c8171eae3bdb692373cd", null ],
    [ "SetHeight", "class_resizable.html#a09283ee90e60c8863f45421726c27c95", null ],
    [ "SetSize", "class_resizable.html#a7ec0874091e5426b4940495e1dcf7da6", null ],
    [ "SetSize", "class_resizable.html#ab47cbbdf06eb564eed1ff98be302002d", null ],
    [ "SetWidth", "class_resizable.html#a5e97d3cc79ae9f6dde05f9531f5f3d50", null ]
];