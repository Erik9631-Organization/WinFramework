var class_activatable =
[
    [ "IsActive", "class_activatable.html#ab44dc7a1886005ee1690fd7d14ee33ca", null ],
    [ "SetActive", "class_activatable.html#a5ff9145e9b50e74a95f7f666b57f205c", null ]
];