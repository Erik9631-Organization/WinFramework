var class_draggable =
[
    [ "GetDragContent", "class_draggable.html#a3431f0f3441983056b190946aed31bdb", null ]
];