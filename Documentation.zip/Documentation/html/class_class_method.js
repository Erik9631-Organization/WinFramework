var class_class_method =
[
    [ "ClassMethod", "class_class_method.html#aaba0c19a81ed2292cea46f98023b57a8", null ],
    [ "Invoke", "class_class_method.html#a0e6b57eaab690e7d28e1768e897075ae", null ]
];