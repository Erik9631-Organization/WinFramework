var class_panel =
[
    [ "Panel", "class_panel.html#a977ca8ff101666a0336945dc12a44144", null ],
    [ "Panel", "class_panel.html#a6234e4c8c430bb1faca3dd97d203b908", null ],
    [ "Panel", "class_panel.html#a77bf7cbaf7291dc5123e3c304522d119", null ]
];