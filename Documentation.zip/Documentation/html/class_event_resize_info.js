var class_event_resize_info =
[
    [ "EventResizeInfo", "class_event_resize_info.html#ae667a219ebccbaff15940081340d5ac5", null ],
    [ "~EventResizeInfo", "class_event_resize_info.html#afbd5340a0105e2ee02d5f60aec860fda", null ],
    [ "GetSize", "class_event_resize_info.html#a431261c33c961631373fdba445e90f94", null ],
    [ "GetSrc", "class_event_resize_info.html#acedf0e465d7e13c3c0cec67a12b124d4", null ]
];